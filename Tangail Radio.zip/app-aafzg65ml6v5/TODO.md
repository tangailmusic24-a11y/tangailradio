# Task: Tangail Radio Online Radio Station Implementation

## Plan
- [ ] Initialize Project Structure & Types
  - [ ] Define types in `src/types/types.ts`
  - [ ] Create API functions in `src/db/api.ts`
- [ ] Implement Auth System
  - [ ] Update `src/context/AuthContext.tsx`
  - [ ] Update `src/components/common/RouteGuard.tsx`
  - [ ] Create Login Page `src/pages/Login.tsx`
- [ ] Build Frontend (Bengali UI)
  - [ ] Layout with Header, Navigation (Home only)
  - [ ] Breaking News Section
  - [ ] Picture Slider
  - [ ] Notice Board
  - [ ] Live Radio Player (Auto DJ enabled)
- [x] Build Admin Panel (Hidden)
  - [x] Admin Dashboard
  - [x] News Management
  - [x] Notice Board Management
  - [x] Slider Management
  - [x] Track Upload & Gallery (Updated with Link Upload)
  - [x] Playlist Builder (Shuffle, Sequential, Timed)
- [x] Implement Radio Logic (Auto DJ)
  - [x] Audio Player with Playlist support
  - [x] Progres bar & Metadata extraction
- [ ] Final Polish & Verification
  - [ ] Search for real images/audio placeholders
  - [ ] Linting and bug fixes

## Notes
- Admin Login: `mdashiktng` / `ashik1122@#$`
- Language: Bengali (UI)
- Storage: `tangail_radio_images` and `tangail_radio_audio`
