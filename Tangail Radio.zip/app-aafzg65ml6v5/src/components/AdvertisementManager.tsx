import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { fetchTracks, createTrack, updateTrack, deleteTrack } from '@/db/api';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { Upload, Trash2, Play, Loader2, DollarSign, Clock, Edit, Building2 } from 'lucide-react';
import { motion } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

interface Track {
  id: string;
  title: string;
  artist?: string;
  audio_url: string;
  intro_url?: string;
  duration?: number;
  type?: string;
  scheduled_time?: string;
  last_played_at?: string;
  created_at: string;
}

export const AdvertisementManager: React.FC = () => {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingTrack, setEditingTrack] = useState<Track | null>(null);

  // ফর্ম স্টেট
  const [title, setTitle] = useState('');
  const [advertiser, setAdvertiser] = useState('');
  const [description, setDescription] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [adFile, setAdFile] = useState<File | null>(null);
  const [introFile, setIntroFile] = useState<File | null>(null);

  useEffect(() => {
    loadAdvertisements();
  }, []);

  const loadAdvertisements = async () => {
    setLoading(true);
    try {
      const allTracks = await fetchTracks();
      const ads = allTracks.filter(t => t.type === 'advertisement');
      setTracks(ads);
    } catch (error) {
      console.error('Error loading advertisements:', error);
      toast.error('বিজ্ঞাপন লোড করতে ব্যর্থ হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (file: File, bucketName: string): Promise<string | null> => {
    try {
      console.log('আপলোড শুরু হচ্ছে:', file.name, 'সাইজ:', (file.size / 1024 / 1024).toFixed(2), 'MB', 'বাকেট:', bucketName);
      
      // Check file size (50MB limit)
      const maxSize = 50 * 1024 * 1024; // 50MB
      if (file.size > maxSize) {
        toast.error(`ফাইল সাইজ অনেক বড় (${(file.size / 1024 / 1024).toFixed(2)} MB)। সর্বোচ্চ ৫০ MB অনুমোদিত।`);
        return null;
      }

      // Check file type
      const allowedTypes = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/mp4', 'audio/aac'];
      if (!allowedTypes.includes(file.type) && !file.name.match(/\.(mp3|wav|ogg|mp4|aac|m4a)$/i)) {
        toast.error(`অসমর্থিত ফাইল টাইপ: ${file.type}। শুধুমাত্র অডিও ফাইল অনুমোদিত।`);
        return null;
      }
      
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `${fileName}`;

      const { data, error: uploadError } = await supabase.storage
        .from(bucketName)
        .upload(filePath, file, { 
          cacheControl: '3600',
          upsert: false 
        });

      if (uploadError) {
        console.error('আপলোড ত্রুটি:', uploadError);
        toast.error(`আপলোড ব্যর্থ: ${uploadError.message}`);
        throw uploadError;
      }

      if (!data) {
        console.error('আপলোড ডেটা পাওয়া যায়নি');
        toast.error('আপলোড ডেটা পাওয়া যায়নি');
        return null;
      }

      const { data: urlData } = supabase.storage
        .from(bucketName)
        .getPublicUrl(data.path);

      console.log('আপলোড সফল:', urlData.publicUrl);
      return urlData.publicUrl;
    } catch (error: any) {
      console.error('আপলোড ত্রুটি:', error);
      toast.error(`ফাইল আপলোড ব্যর্থ: ${error?.message || 'অজানা ত্রুটি'}`);
      return null;
    }
  };

  const handleSubmit = async () => {
    if (!title.trim()) {
      toast.error('বিজ্ঞাপনের শিরোনাম লিখুন');
      return;
    }

    if (!adFile) {
      toast.error('বিজ্ঞাপন অডিও ফাইল নির্বাচন করুন');
      return;
    }

    setUploading(true);
    try {
      console.log('বিজ্ঞাপন আপলোড প্রক্রিয়া শুরু হচ্ছে...');
      
      // আপলোড বিজ্ঞাপন অডিও
      const adUrl = await handleFileUpload(adFile, 'tangail_radio_audio');
      if (!adUrl) {
        console.error('বিজ্ঞাপন অডিও URL পাওয়া যায়নি');
        setUploading(false);
        return;
      }

      console.log('বিজ্ঞাপন অডিও আপলোড সফল:', adUrl);

      // আপলোড ইন্ট্রো (যদি থাকে)
      let introUrl: string | undefined = undefined;
      if (introFile) {
        console.log('ইন্ট্রো আপলোড করা হচ্ছে...');
        introUrl = await handleFileUpload(introFile, 'tangail_radio_audio') || undefined;
        if (introUrl) {
          console.log('ইন্ট্রো আপলোড সফল:', introUrl);
        }
      }

      console.log('ডাটাবেসে সংরক্ষণ করা হচ্ছে...');
      
      // ডাটাবেসে সংরক্ষণ করুন
      await createTrack({
        title,
        audio_url: adUrl,
        intro_url: introUrl,
        type: 'advertisement',
        scheduled_time: scheduledTime || undefined,
        artist: advertiser || 'বিজ্ঞাপনদাতা'
      });

      console.log('বিজ্ঞাপন সফলভাবে সংরক্ষিত হয়েছে');
      toast.success('বিজ্ঞাপন সফলভাবে যুক্ত হয়েছে');
      
      // রিসেট ফর্ম
      setTitle('');
      setAdvertiser('');
      setDescription('');
      setScheduledTime('');
      setAdFile(null);
      setIntroFile(null);
      
      // রিলোড তালিকা
      await loadAdvertisements();
    } catch (error: any) {
      console.error('বিজ্ঞাপন তৈরি করতে ত্রুটি:', error);
      toast.error(`বিজ্ঞাপন যুক্ত করতে ব্যর্থ: ${error?.message || 'অজানা ত্রুটি'}`);
    } finally {
      setUploading(false);
    }
  };

  const handleEdit = (track: Track) => {
    setEditingTrack(track);
    setTitle(track.title);
    setAdvertiser(track.artist || '');
    setScheduledTime(track.scheduled_time || '');
    setIsEditDialogOpen(true);
  };

  const handleUpdate = async () => {
    if (!editingTrack || !title.trim()) {
      toast.error('শিরোনাম পূরণ করুন');
      return;
    }

    try {
      await updateTrack(editingTrack.id, {
        title,
        artist: advertiser || 'বিজ্ঞাপনদাতা',
        scheduled_time: scheduledTime || undefined
      });

      toast.success('বিজ্ঞাপন আপডেট হয়েছে');
      setIsEditDialogOpen(false);
      setEditingTrack(null);
      setTitle('');
      setAdvertiser('');
      setScheduledTime('');
      loadAdvertisements();
    } catch (error) {
      console.error('Error updating advertisement:', error);
      toast.error('আপডেট করতে ব্যর্থ হয়েছে');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('আপনি কি এই বিজ্ঞাপনটি মুছে ফেলতে চান?')) return;
    
    try {
      await deleteTrack(id);
      toast.success('বিজ্ঞাপন মুছে ফেলা হয়েছে');
      loadAdvertisements();
    } catch (error) {
      console.error('Error deleting advertisement:', error);
      toast.error('মুছে ফেলতে ব্যর্থ হয়েছে');
    }
  };

  const formatPlayCount = (lastPlayed?: string) => {
    if (!lastPlayed) return 'এখনো প্লে হয়নি';
    const date = new Date(lastPlayed);
    return `শেষ প্লে: ${date.toLocaleDateString('bn-BD')}`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>বিজ্ঞাপন ম্যানেজমেন্ট</CardTitle>
        <CardDescription>
          বিজ্ঞাপন অডিও আপলোড করুন এবং প্রচার পরিচালনা করুন
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* আপলোড ফর্ম */}
        <div className="border rounded-xl p-6 bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-950/20 dark:to-blue-950/20 space-y-4">
          <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-green-600" />
            নতুন বিজ্ঞাপন যুক্ত করুন
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>বিজ্ঞাপনের শিরোনাম *</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="যেমন: নতুন পণ্য লঞ্চ"
              />
            </div>

            <div className="space-y-2">
              <Label>বিজ্ঞাপনদাতার নাম (ঐচ্ছিক)</Label>
              <Input
                value={advertiser}
                onChange={(e) => setAdvertiser(e.target.value)}
                placeholder="কোম্পানি/প্রতিষ্ঠানের নাম"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>শিডিউল সময় (ঐচ্ছিক)</Label>
            <Input
              type="time"
              value={scheduledTime}
              onChange={(e) => setScheduledTime(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              নির্দিষ্ট সময়ে স্বয়ংক্রিয়ভাবে প্লে হবে (খালি রাখলে র‍্যান্ডমলি প্লে হবে)
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>বিজ্ঞাপন অডিও ফাইল *</Label>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => document.getElementById('ad_audio_input')?.click()}
                >
                  <Upload className="w-4 h-4 mr-2" />
                  {adFile ? adFile.name : 'ফাইল নির্বাচন করুন'}
                </Button>
                <input
                  id="ad_audio_input"
                  type="file"
                  accept="audio/*"
                  className="hidden"
                  onChange={(e) => setAdFile(e.target.files?.[0] || null)}
                />
                {adFile && (
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setAdFile(null)}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label>ইন্ট্রো অডিও (ঐচ্ছিক)</Label>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => document.getElementById('ad_intro_input')?.click()}
                >
                  <Upload className="w-4 h-4 mr-2" />
                  {introFile ? introFile.name : 'ইন্ট্রো নির্বাচন করুন'}
                </Button>
                <input
                  id="ad_intro_input"
                  type="file"
                  accept="audio/*"
                  className="hidden"
                  onChange={(e) => setIntroFile(e.target.files?.[0] || null)}
                />
                {introFile && (
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setIntroFile(null)}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                বিজ্ঞাপনের আগে ইন্ট্রো প্লে হবে
              </p>
            </div>
          </div>

          <Button
            onClick={handleSubmit}
            disabled={uploading}
            className="w-full"
            size="lg"
          >
            {uploading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                আপলোড হচ্ছে...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                বিজ্ঞাপন যুক্ত করুন
              </>
            )}
          </Button>
        </div>

        {/* বিজ্ঞাপন তালিকা */}
        <div className="space-y-3">
          <h3 className="font-bold text-lg">বিজ্ঞাপন তালিকা ({tracks.length}টি)</h3>
          
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : tracks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              কোনো বিজ্ঞাপন নেই। নতুন বিজ্ঞাপন যুক্ত করুন।
            </div>
          ) : (
            <div className="space-y-2">
              {tracks.map((track) => (
                <motion.div
                  key={track.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="border rounded-lg p-4 bg-card hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-green-600" />
                        <h4 className="font-bold">{track.title}</h4>
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                        {track.artist && track.artist !== 'বিজ্ঞাপনদাতা' && (
                          <span className="flex items-center gap-1">
                            <Building2 className="w-3 h-3" />
                            {track.artist}
                          </span>
                        )}
                        {track.scheduled_time && (
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {track.scheduled_time}
                          </span>
                        )}
                        <span className="text-primary">
                          {formatPlayCount(track.last_played_at)}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const audio = new Audio(track.audio_url);
                          audio.play();
                        }}
                      >
                        <Play className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(track)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(track.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* এডিট ডায়ালগ */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>বিজ্ঞাপন সম্পাদনা করুন</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label>শিরোনাম</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>
              <div>
                <Label>বিজ্ঞাপনদাতা</Label>
                <Input value={advertiser} onChange={(e) => setAdvertiser(e.target.value)} />
              </div>
              <div>
                <Label>শিডিউল সময় (ঐচ্ছিক)</Label>
                <Input
                  type="time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>বাতিল</Button>
                <Button onClick={handleUpdate}>সংরক্ষণ করুন</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* তথ্য বক্স */}
        <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
          <p className="text-sm text-green-800 dark:text-green-200">
            <strong>স্বয়ংক্রিয় প্রচার:</strong> বিজ্ঞাপনগুলি গান ও অনুষ্ঠানের মাঝে স্বয়ংক্রিয়ভাবে প্লে হবে। 
            শিডিউল সময় দিলে নির্দিষ্ট সময়ে প্লে হবে, অন্যথায় র‍্যান্ডমলি প্লে হবে।
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
