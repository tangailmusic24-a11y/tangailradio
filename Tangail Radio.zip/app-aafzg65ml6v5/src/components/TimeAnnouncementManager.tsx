import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { Upload, Trash2, Play, Loader2, Clock, Volume2 } from 'lucide-react';
import { motion } from 'framer-motion';

interface TimeAnnouncement {
  id: string;
  announcement_type: 'hour' | 'minute' | 'period';
  value: number;
  audio_url: string;
  created_at: string;
  updated_at: string;
}

export const TimeAnnouncementManager: React.FC = () => {
  const [hourAnnouncements, setHourAnnouncements] = useState<TimeAnnouncement[]>([]);
  const [minuteAnnouncements, setMinuteAnnouncements] = useState<TimeAnnouncement[]>([]);
  const [periodAnnouncements, setPeriodAnnouncements] = useState<TimeAnnouncement[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState<string | null>(null);

  useEffect(() => {
    loadAnnouncements();
  }, []);

  const loadAnnouncements = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('time_announcements')
        .select('*')
        .order('announcement_type')
        .order('value');

      if (error) throw error;

      const hours = (data || []).filter((a: TimeAnnouncement) => a.announcement_type === 'hour');
      const minutes = (data || []).filter((a: TimeAnnouncement) => a.announcement_type === 'minute');
      const periods = (data || []).filter((a: TimeAnnouncement) => a.announcement_type === 'period');

      setHourAnnouncements(hours);
      setMinuteAnnouncements(minutes);
      setPeriodAnnouncements(periods);
    } catch (error) {
      console.error('Error loading time announcements:', error);
      toast.error('সময় ঘোষণা লোড করতে ব্যর্থ হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `time_${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('tangail_radio_audio')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('tangail_radio_audio')
        .getPublicUrl(filePath);

      return urlData.publicUrl;
    } catch (error) {
      console.error('Upload error:', error);
      return null;
    }
  };

  const handleUpload = async (type: 'hour' | 'minute' | 'period', value: number, file: File) => {
    setUploading(`${type}_${value}`);
    try {
      const audioUrl = await handleFileUpload(file);
      if (!audioUrl) {
        toast.error('অডিও আপলোড ব্যর্থ হয়েছে');
        return;
      }

      const { error } = await supabase
        .from('time_announcements')
        .upsert(
          {
            announcement_type: type,
            value: value,
            audio_url: audioUrl,
            updated_at: new Date().toISOString()
          } as any,
          {
            onConflict: 'announcement_type,value'
          } as any
        );

      if (error) throw error;

      toast.success('অডিও সফলভাবে আপলোড হয়েছে');
      loadAnnouncements();
    } catch (error) {
      console.error('Error uploading:', error);
      toast.error('আপলোড করতে ব্যর্থ হয়েছে');
    } finally {
      setUploading(null);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('এই অডিও ফাইলটি মুছে ফেলতে চান?')) return;

    try {
      const { error } = await supabase
        .from('time_announcements')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast.success('অডিও মুছে ফেলা হয়েছে');
      loadAnnouncements();
    } catch (error) {
      console.error('Error deleting:', error);
      toast.error('মুছে ফেলতে ব্যর্থ হয়েছে');
    }
  };

  const handlePlay = (url: string) => {
    const audio = new Audio(url);
    audio.play();
  };

  const getHourLabel = (hour: number) => {
    const bengaliNumbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return hour.toString().split('').map(d => bengaliNumbers[parseInt(d)]).join('') + ' টা';
  };

  const getMinuteLabel = (minute: number) => {
    const bengaliNumbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return minute.toString().split('').map(d => bengaliNumbers[parseInt(d)]).join('') + ' মিনিট';
  };

  const getPeriodLabel = (period: number) => {
    const periods = ['সকাল', 'দুপুর', 'বিকেল', 'রাত'];
    return periods[period - 1] || '';
  };

  const renderUploadButton = (type: 'hour' | 'minute' | 'period', value: number, existing?: TimeAnnouncement, displayHour?: number) => {
    const isUploading = uploading === `${type}_${value}`;
    const label = type === 'hour' ? getHourLabel(displayHour !== undefined ? displayHour : value) : 
                  type === 'minute' ? getMinuteLabel(value) : 
                  getPeriodLabel(value);

    return (
      <div className="border rounded-lg p-3 bg-card">
        <div className="flex items-center justify-between mb-2">
          <span className="font-bold text-sm">{label}</span>
          {existing && (
            <div className="flex gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={() => handlePlay(existing.audio_url)}
              >
                <Play className="w-3 h-3" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={() => handleDelete(existing.id)}
              >
                <Trash2 className="w-3 h-3 text-destructive" />
              </Button>
            </div>
          )}
        </div>
        <Button
          variant={existing ? "outline" : "default"}
          size="sm"
          className="w-full"
          disabled={isUploading}
          onClick={() => document.getElementById(`upload_${type}_${value}`)?.click()}
        >
          {isUploading ? (
            <>
              <Loader2 className="w-3 h-3 animate-spin mr-1" />
              আপলোড হচ্ছে...
            </>
          ) : (
            <>
              <Upload className="w-3 h-3 mr-1" />
              {existing ? 'পরিবর্তন করুন' : 'আপলোড করুন'}
            </>
          )}
        </Button>
        <input
          id={`upload_${type}_${value}`}
          type="file"
          accept="audio/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleUpload(type, value, file);
          }}
        />
      </div>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-6 h-6" />
          সময় ঘোষণা ম্যানেজমেন্ট
        </CardTitle>
        <CardDescription>
          ১৫/৩০/৪৫ মিনিটের অডিও এবং সকাল/দুপুর/বিকেল/রাতের ঘণ্টার অডিও আলাদাভাবে আপলোড করুন
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* গুরুত্বপূর্ণ তথ্য */}
            <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
              <h4 className="font-bold text-blue-900 dark:text-blue-100 mb-2">ℹ️ গুরুত্বপূর্ণ তথ্য</h4>
              <p className="text-sm text-blue-800 dark:text-blue-200">
                প্রতিটি সময়ের জন্য আলাদা অডিও ফাইল আপলোড করুন। সকালের অডিও শুধু সকালে, দুপুরের অডিও শুধু দুপুরে, বিকেলের অডিও শুধু বিকেলে এবং রাতের অডিও শুধু রাতে বাজবে। প্রতি ১৫ মিনিট পর পর (XX:১৫, XX:৩০, XX:৪৫) সময় ঘোষণা হবে।
              </p>
            </div>

            {/* মিনিটের অডিও */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-primary" />
                <h3 className="font-bold text-lg">১. ১৫/৩০/৪৫ মিনিটের অডিও</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                ১৫ মিনিট, ৩০ মিনিট এবং ৪৫ মিনিট - এই তিনটির জন্য আলাদা অডিও ফাইল আপলোড করুন
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {[15, 30, 45].map(minute => {
                  const existing = minuteAnnouncements.find(a => a.value === minute);
                  return (
                    <motion.div
                      key={minute}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                    >
                      {renderUploadButton('minute', minute, existing)}
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* ঘণ্টার অডিও */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-primary" />
                <h3 className="font-bold text-lg">২. ঘণ্টার অডিও</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                সকালের AM, দুপুরের PM, বিকেলের PM এবং রাতের AM - এই চার ক্যাটাগরিতে ঘণ্টার অডিও ফাইল আপলোড করুন
              </p>

              {/* সকালের AM */}
              <div className="border rounded-lg p-4 bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20">
                <h4 className="font-bold mb-2 text-orange-900 dark:text-orange-100">সকালের AM (৫:০০ - ১১:৫৯)</h4>
                <p className="text-xs text-muted-foreground mb-3">সকালের সময়ের জন্য ঘণ্টার অডিও (৫-১১ টা)</p>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
                  {[5, 6, 7, 8, 9, 10, 11].map(hour24 => {
                    const hour12 = hour24;
                    const existing = hourAnnouncements.find(a => a.value === hour24);
                    return (
                      <motion.div
                        key={`morning_${hour24}`}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                      >
                        {renderUploadButton('hour', hour24, existing)}
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* দুপুরের PM */}
              <div className="border rounded-lg p-4 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20">
                <h4 className="font-bold mb-2 text-blue-900 dark:text-blue-100">দুপুরের PM (১২:০০ - ২:৫৯)</h4>
                <p className="text-xs text-muted-foreground mb-3">দুপুরের সময়ের জন্য ঘণ্টার অডিও (১২ টা, ১ টা, ২ টা)</p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {[12, 13, 14].map(hour24 => {
                    const hour12 = hour24 === 12 ? 12 : hour24 - 12;
                    const existing = hourAnnouncements.find(a => a.value === hour24);
                    return (
                      <motion.div
                        key={`noon_${hour24}`}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                      >
                        {renderUploadButton('hour', hour24, existing, hour12)}
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* বিকেলের PM */}
              <div className="border rounded-lg p-4 bg-gradient-to-br from-green-50 to-teal-50 dark:from-green-950/20 dark:to-teal-950/20">
                <h4 className="font-bold mb-2 text-green-900 dark:text-green-100">বিকেলের PM (৩:০০ - ৫:৫৯)</h4>
                <p className="text-xs text-muted-foreground mb-3">বিকেলের সময়ের জন্য ঘণ্টার অডিও (৩ টা, ৪ টা, ৫ টা)</p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {[15, 16, 17].map(hour24 => {
                    const hour12 = hour24 - 12;
                    const existing = hourAnnouncements.find(a => a.value === hour24);
                    return (
                      <motion.div
                        key={`evening_${hour24}`}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                      >
                        {renderUploadButton('hour', hour24, existing, hour12)}
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* রাতের AM/PM */}
              <div className="border rounded-lg p-4 bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950/20 dark:to-purple-950/20">
                <h4 className="font-bold mb-2 text-indigo-900 dark:text-indigo-100">রাতের PM/AM (৬:০০ - ৪:৫৯)</h4>
                <p className="text-xs text-muted-foreground mb-3">সন্ধ্যা ও রাতের সময়ের জন্য ঘণ্টার অডিও</p>
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-indigo-800 dark:text-indigo-200">সন্ধ্যা (৬ PM - ১১ PM):</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
                    {[18, 19, 20, 21, 22, 23].map(hour24 => {
                      const hour12 = hour24 - 12;
                      const existing = hourAnnouncements.find(a => a.value === hour24);
                      return (
                        <motion.div
                          key={`night_pm_${hour24}`}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                        >
                          {renderUploadButton('hour', hour24, existing, hour12)}
                        </motion.div>
                      );
                    })}
                  </div>
                  <p className="text-xs font-semibold text-indigo-800 dark:text-indigo-200 mt-3">মধ্যরাত (১২ AM - ৪ AM):</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
                    {[0, 1, 2, 3, 4].map(hour24 => {
                      const hour12 = hour24 === 0 ? 12 : hour24;
                      const existing = hourAnnouncements.find(a => a.value === hour24);
                      return (
                        <motion.div
                          key={`night_am_${hour24}`}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                        >
                          {renderUploadButton('hour', hour24, existing, hour12)}
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* তথ্য বক্স */}
            <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 space-y-2">
              <h4 className="font-bold text-blue-900 dark:text-blue-100">কিভাবে কাজ করে:</h4>
              <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1 list-disc list-inside">
                <li>প্রতি ১৫ মিনিটে (XX:০০, XX:১৫, XX:৩০, XX:৪৫) স্বয়ংক্রিয়ভাবে সময় ঘোষণা হবে</li>
                <li>পূর্ণ ঘণ্টায় (যেমন ১০:০০) ঘণ্টা + সময়ের অংশ অডিও প্লে হবে</li>
                <li>১৫/৩০/৪৫ মিনিটে ঘণ্টা + মিনিট + সময়ের অংশ অডিও প্লে হবে</li>
                <li>সময় ঘোষণার সময় বর্তমান গান/সংবাদ/অনুষ্ঠান বন্ধ হবে (শুধু আযান বাদে)</li>
                <li>ঘোষণা শেষে আগের কন্টেন্ট পুনরায় চালু হবে</li>
              </ul>
            </div>

            {/* উদাহরণ */}
            <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
              <h4 className="font-bold text-green-900 dark:text-green-100 mb-2">উদাহরণ:</h4>
              <div className="text-sm text-green-800 dark:text-green-200 space-y-1">
                <p>• ১০:০০ সকাল - "দশটা" + "সকাল"</p>
                <p>• ১০:১৫ সকাল - "দশটা" + "পনেরো মিনিট" + "সকাল"</p>
                <p>• ১০:৩০ সকাল - "দশটা" + "ত্রিশ মিনিট" + "সকাল"</p>
                <p>• ১০:৪৫ সকাল - "দশটা" + "পঁয়তাল্লিশ মিনিট" + "সকাল"</p>
                <p>• ২:০০ দুপুর - "দুইটা" + "দুপুর"</p>
                <p>• ৮:৩০ রাত - "আটটা" + "ত্রিশ মিনিট" + "রাত"</p>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};
