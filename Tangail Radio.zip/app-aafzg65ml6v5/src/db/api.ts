import { supabase } from './supabase';
import { News, Notice, SliderImage, Track, Playlist, StationSettings, Profile, RadioSession } from '../types/types';

// News
export const fetchNews = async () => {
  const { data, error } = await supabase.from('news').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return data as News[];
};

export const createNews = async (content: string) => {
  const { data, error } = await supabase.from('news').insert({ content }).select().single();
  if (error) throw error;
  return data as News;
};

export const deleteNews = async (id: string) => {
  const { error } = await supabase.from('news').delete().eq('id', id);
  if (error) throw error;
};

// Notices
export const fetchNotices = async () => {
  const { data, error } = await supabase.from('notices').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return data as Notice[];
};

export const createNotice = async (title: string, content: string) => {
  const { data, error } = await supabase.from('notices').insert({ title, content }).select().single();
  if (error) throw error;
  return data as Notice;
};

export const deleteNotice = async (id: string) => {
  const { error } = await supabase.from('notices').delete().eq('id', id);
  if (error) throw error;
};

// Slider
export const fetchSlider = async () => {
  const { data, error } = await supabase.from('slider').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return data as SliderImage[];
};

export const createSliderImage = async (image_url: string, title?: string) => {
  const { data, error } = await supabase.from('slider').insert({ image_url, title }).select().single();
  if (error) throw error;
  return data as SliderImage;
};

export const deleteSliderImage = async (id: string) => {
  const { error } = await supabase.from('slider').delete().eq('id', id);
  if (error) throw error;
};

// Tracks
export const fetchTracks = async (type?: string) => {
  let query = supabase.from('tracks').select('*').order('created_at', { ascending: false });
  if (type) {
    query = query.eq('type', type);
  }
  const { data, error } = await query;
  if (error) throw error;
  return data as Track[];
};

export const createTrack = async (track: Partial<Track>) => {
  const { data, error } = await supabase.from('tracks').insert(track).select().single();
  if (error) throw error;
  return data as Track;
};

export const deleteTrack = async (id: string) => {
  const { error } = await supabase.from('tracks').delete().eq('id', id);
  if (error) throw error;
};

export const updateTrack = async (id: string, updates: Partial<{
  title: string;
  artist: string;
  audio_url: string;
  duration: number;
  type: string;
  intro_type: string;
  scheduled_time: string;
}>) => {
  const { error } = await supabase.from('tracks').update(updates).eq('id', id);
  if (error) throw error;
};

// Radio Session Management
export const getRadioSession = async (): Promise<RadioSession & { track: Track | null }> => {
  const { data, error } = await supabase
    .from('radio_session')
    .select('*')
    .eq('id', 1)
    .single();
  if (error) throw error;
  
  const session = data as any;
  
  // If we have dynamic info, reconstruct the track object
  if (session.current_track_url) {
    session.track = {
      id: session.current_track_id,
      title: session.current_track_title || 'Untitled Dynamic Track',
      audio_url: session.current_track_url,
      duration: session.current_track_duration ? Number(session.current_track_duration) : undefined,
      type: session.current_track_type || 'jingle',
      created_at: session.updated_at
    } as Track;
  } else if (session.current_track_id) {
    // If it's a UUID, fetch it manually
    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(session.current_track_id);
    if (isUUID) {
      const { data: trackData } = await supabase
        .from('tracks')
        .select('*')
        .eq('id', session.current_track_id)
        .maybeSingle();
      session.track = trackData as Track;
    }
  }
  
  return session;
};

export const updateRadioSession = async (track: Track, started_at: Date): Promise<void> => {
  // Check current session first to avoid redundant updates from multiple clients
  const { data: current } = await supabase.from('radio_session').select('*').eq('id', 1).single();
  
  if (current) {
    const sessionStartedAt = new Date(current.started_at);
    const now = new Date();
    // If someone else already updated it in the last 5 seconds, AND it's the same track AND the info is already there, skip
    const isSameTrack = current.current_track_id === track.id;
    const hasFullInfo = current.current_track_url === track.audio_url;
    
    if (isSameTrack && hasFullInfo && (now.getTime() - sessionStartedAt.getTime() < 5000)) {
       return;
    }
  }

  const { error } = await supabase
    .from('radio_session')
    .update({ 
      current_track_id: track.id, 
      started_at: started_at.toISOString(),
      updated_at: new Date().toISOString(),
      interrupted_track_id: null,
      interrupt_offset: null,
      interrupt_type: null,
      current_track_url: track.audio_url,
      current_track_title: track.title,
      current_track_duration: track.duration,
      current_track_type: track.type
    })
    .eq('id', 1);
  if (error) throw error;
};

// Playlist Schedule API
export const fetchPlaylistSchedules = async () => {
  const { data, error } = await supabase.from('playlist_schedules').select('*').order('start_time');
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createPlaylistSchedule = async (schedule: {
  name: string;
  start_time: string;
  end_time: string;
  track_ids: string[];
  days_of_week: number[];
  active: boolean;
}) => {
  const { error } = await supabase.from('playlist_schedules').insert(schedule);
  if (error) throw error;
};

export const updatePlaylistSchedule = async (id: string, updates: Partial<{
  name: string;
  start_time: string;
  end_time: string;
  track_ids: string[];
  days_of_week: number[];
  active: boolean;
}>) => {
  const { error } = await supabase.from('playlist_schedules').update(updates).eq('id', id);
  if (error) throw error;
};

export const deletePlaylistSchedule = async (id: string) => {
  const { error } = await supabase.from('playlist_schedules').delete().eq('id', id);
  if (error) throw error;
};

// Prayer Times API
export const fetchPrayerTimes = async () => {
  const { data, error } = await supabase.from('prayer_times').select('*').eq('id', 1).maybeSingle();
  if (error) throw error;
  return data;
};

export const updatePrayerTimes = async (updates: Partial<{
  fajr_time: string;
  dhuhr_time: string;
  asr_time: string;
  maghrib_time: string;
  isha_time: string;
  jummah_time: string;
  active: boolean;
}>) => {
  const { error } = await supabase.from('prayer_times').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', 1);
  if (error) throw error;
};

// Programs API
export const fetchPrograms = async () => {
  const { data, error } = await supabase.from('programs').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createProgram = async (program: {
  title: string;
  description?: string;
  image_url?: string;
  host_name?: string;
  schedule_time?: string;
  days_of_week: number[];
  active: boolean;
}) => {
  const { error } = await supabase.from('programs').insert(program);
  if (error) throw error;
};

export const updateProgram = async (id: string, updates: Partial<{
  title: string;
  description?: string;
  image_url?: string;
  host_name?: string;
  schedule_time?: string;
  days_of_week: number[];
  active: boolean;
}>) => {
  const { error } = await supabase.from('programs').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id);
  if (error) throw error;
};

export const deleteProgram = async (id: string) => {
  const { error } = await supabase.from('programs').delete().eq('id', id);
  if (error) throw error;
};

// Comments API
export const fetchComments = async (approvedOnly = false) => {
  let query = supabase.from('comments').select('*').order('created_at', { ascending: false });
  if (approvedOnly) {
    query = query.eq('approved', true);
  }
  const { data, error } = await query;
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createComment = async (comment: {
  name: string;
  email?: string;
  comment: string;
}) => {
  const { error } = await supabase.from('comments').insert(comment);
  if (error) throw error;
};

export const approveComment = async (id: string) => {
  const { error } = await supabase.from('comments').update({ approved: true }).eq('id', id);
  if (error) throw error;
};

export const deleteComment = async (id: string) => {
  const { error } = await supabase.from('comments').delete().eq('id', id);
  if (error) throw error;
};

// External Streams API
export const fetchExternalStreams = async () => {
  const { data, error } = await supabase.from('external_streams').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createExternalStream = async (stream: {
  name: string;
  stream_url: string;
  schedule_time?: string;
  end_time?: string;
  days_of_week: number[];
  active: boolean;
}) => {
  const { error } = await supabase.from('external_streams').insert(stream);
  if (error) throw error;
};

export const updateExternalStream = async (id: string, updates: Partial<{
  name: string;
  stream_url: string;
  schedule_time?: string;
  end_time?: string;
  days_of_week: number[];
  active: boolean;
}>) => {
  const { error } = await supabase.from('external_streams').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id);
  if (error) throw error;
};

export const deleteExternalStream = async (id: string) => {
  const { error } = await supabase.from('external_streams').delete().eq('id', id);
  if (error) throw error;
};

// Dashboard Statistics API
export const fetchDashboardStats = async () => {
  // Get track counts by type
  const { data: tracks } = await supabase.from('tracks').select('type');
  
  const stats = {
    total_tracks: tracks?.length || 0,
    total_songs: tracks?.filter(t => t.type === 'song').length || 0,
    total_programs: tracks?.filter(t => t.type === 'program').length || 0,
    total_news: tracks?.filter(t => t.type === 'news').length || 0,
    total_adhan: tracks?.filter(t => t.type === 'adhan').length || 0,
    total_jingles: tracks?.filter(t => t.type === 'jingle').length || 0,
    total_listeners: 0,
    online_listeners: 0
  };

  // Get listener counts
  const { count: totalListeners } = await supabase
    .from('listener_sessions')
    .select('*', { count: 'exact', head: true });
  
  // Online listeners are those who pinged in the last 5 minutes
  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
  const { count: onlineListeners } = await supabase
    .from('listener_sessions')
    .select('*', { count: 'exact', head: true })
    .gte('last_ping', fiveMinutesAgo);

  stats.total_listeners = totalListeners || 0;
  stats.online_listeners = onlineListeners || 0;

  return stats;
};

// Listener tracking
export const trackListener = async (sessionId: string) => {
  const { error } = await supabase
    .from('listener_sessions')
    .upsert({ 
      session_id: sessionId, 
      last_ping: new Date().toISOString(),
      user_agent: navigator.userAgent
    }, { 
      onConflict: 'session_id' 
    });
  if (error) console.error('Listener tracking error:', error);
};

// Next Track Picker Logic with Interrupt/Resume System
export const pickNextLiveTrack = async (): Promise<Track | null> => {
  const now = new Date();
  // Get Bangladesh time
  const bdTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Dhaka' }));
  const currentTimeStr = bdTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }); // "HH:MM"
  const dayOfWeek = bdTime.getDay(); // 0 = Sunday, 5 = Friday
  
  // Get current session state
  const { data: session } = await supabase
    .from('radio_session')
    .select('*')
    .eq('id', 1)
    .maybeSingle();

  // Helper: Create dynamic track from prayer/time announcement audio
  const createPrayerTrack = (audioUrl: string, title: string, type: 'intro' | 'adhan'): Track => {
    return {
      id: `prayer_${type}_${Date.now()}`,
      title,
      audio_url: audioUrl,
      type: 'adhan',
      created_at: new Date().toISOString()
    } as Track;
  };

  // Helper: Save current track state before interruption
  const saveInterruptState = async (currentTrackId: string, offset: number, interruptType: string) => {
    await supabase.from('radio_session').update({
      interrupted_track_id: currentTrackId,
      interrupted_at: now.toISOString(),
      interrupt_offset: offset,
      interrupt_type: interruptType
    }).eq('id', 1);
  };

  // STEP 1: Check if we need to resume an interrupted track
  if (session?.interrupted_track_id && !session?.pending_content_id) {
    const { data: interruptedTrack } = await supabase
      .from('tracks')
      .select('*')
      .eq('id', session.interrupted_track_id)
      .maybeSingle();

    if (interruptedTrack) {
      // Clear interrupt state
      await supabase.from('radio_session').update({
        interrupted_track_id: null,
        interrupted_at: null,
        interrupt_offset: null,
        interrupt_type: null
      }).eq('id', 1);
      
      // Return the interrupted track (client should resume from interrupt_offset)
      return { ...interruptedTrack, resume_from: session.interrupt_offset || 0 } as any;
    }
  }

  // STEP 2: Check if there's pending content waiting after intro
  if (session?.pending_content_id && session?.pending_content_type) {
    let pendingTrack: Track | null = null;
    
    // Check if it's a UUID (should exist in tracks table)
    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(session.pending_content_id);
    
    if (isUUID) {
      const { data } = await supabase
        .from('tracks')
        .select('*')
        .eq('id', session.pending_content_id)
        .maybeSingle();
      pendingTrack = data as Track;
    } else if (session.pending_content_url) {
      // It's a dynamic pending track
      pendingTrack = {
        id: session.pending_content_id,
        title: session.pending_content_title || 'Untitled Pending Track',
        audio_url: session.pending_content_url,
        duration: session.pending_content_duration ? Number(session.pending_content_duration) : undefined,
        type: 'jingle',
        created_at: session.updated_at
      } as Track;
    }

    if (pendingTrack) {
      // Clear pending content
      await supabase.from('radio_session').update({ 
        pending_content_type: null, 
        pending_content_id: null,
        pending_content_url: null,
        pending_content_title: null,
        pending_content_duration: null,
        pending_content_extra: null
      }).eq('id', 1);
      
      if (isUUID) {
        await supabase.from('tracks').update({ last_played_at: now.toISOString() }).eq('id', pendingTrack.id);
      }
      return pendingTrack;
    }
  }

  
  // STEP 3: Check for Prayer Times (HIGHEST PRIORITY - INTERRUPTS EVERYTHING)
  const { data: prayerTimes } = await supabase
    .from('prayer_times')
    .select('*')
    .eq('id', 1)
    .eq('active', true)
    .maybeSingle();

  if (prayerTimes) {
    let prayerKey: string | null = null;
    
    // New logic for prayerKey detection with 3-minute window
    const checkTimeMatch = (targetTime: string) => {
      if (!targetTime) return false;
      const [targetH, targetM] = targetTime.split(':').map(Number);
      const currentH = bdTime.getHours();
      const currentM = bdTime.getMinutes();
      
      const targetTotal = targetH * 60 + targetM;
      const currentTotal = currentH * 60 + currentM;
      
      // Return true if we are within 0-2 minutes of the target time
      return currentTotal >= targetTotal && currentTotal < targetTotal + 3;
    };

    if (dayOfWeek === 5) {
      // Friday - check Fajr, Asr, Maghrib, Isha, Jummah (not Dhuhr)
      if (checkTimeMatch(prayerTimes.fajr_time)) prayerKey = 'fajr';
      else if (checkTimeMatch(prayerTimes.asr_time)) prayerKey = 'asr';
      else if (checkTimeMatch(prayerTimes.maghrib_time)) prayerKey = 'maghrib';
      else if (checkTimeMatch(prayerTimes.isha_time)) prayerKey = 'isha';
      else if (checkTimeMatch(prayerTimes.jummah_time)) prayerKey = 'jummah';
    } else {
      // Other days - check all 5 prayers (not Jummah)
      if (checkTimeMatch(prayerTimes.fajr_time)) prayerKey = 'fajr';
      else if (checkTimeMatch(prayerTimes.dhuhr_time)) prayerKey = 'dhuhr';
      else if (checkTimeMatch(prayerTimes.asr_time)) prayerKey = 'asr';
      else if (checkTimeMatch(prayerTimes.maghrib_time)) prayerKey = 'maghrib';
      else if (checkTimeMatch(prayerTimes.isha_time)) prayerKey = 'isha';
    }

    if (prayerKey) {
      const introUrl = prayerTimes[`${prayerKey}_intro_url` as keyof typeof prayerTimes] as string | undefined;
      const adhanUrl = prayerTimes[`${prayerKey}_adhan_url` as keyof typeof prayerTimes] as string | undefined;

      // Check if we already played this specific prayer today
      const dateStr = bdTime.toISOString().split('T')[0];
      const prayerDayKey = `${prayerKey}_${dateStr}`;
      
      const shouldPlay = session?.last_prayer_played !== prayerDayKey;

      if (shouldPlay) {
        console.log(`✅ আযান প্রচার শুরু হচ্ছে: ${prayerKey}`);
        
        // Update session to mark this prayer as played
        await supabase.from('radio_session').update({
          last_prayer_played: prayerDayKey,
          last_prayer_at: now.toISOString()
        }).eq('id', 1);

        // INTERRUPT current playback if needed
        if (session?.current_track_id && !session?.interrupted_track_id) {
          await saveInterruptState(session.current_track_id, 0, 'adhan');
        }

        // Play intro first if available
        if (introUrl) {
          console.log(`🎵 ইন্ট্রো প্রচার করা হচ্ছে: ${prayerKey}`);
          const introTrack = createPrayerTrack(introUrl, `${prayerKey} ইন্ট্রো`, 'intro');
          
          // Set adhan as pending
          if (adhanUrl) {
            const adhanTrack = createPrayerTrack(adhanUrl, `${prayerKey} আযান`, 'adhan');
            await supabase.from('radio_session').update({
              pending_content_type: 'adhan',
              pending_content_id: adhanTrack.id as any,
              pending_content_url: adhanTrack.audio_url,
              pending_content_title: adhanTrack.title,
              pending_content_duration: adhanTrack.duration
            }).eq('id', 1);
          }
          
          return introTrack;
        }
        
        // Play adhan directly if no intro
        if (adhanUrl) {
          return createPrayerTrack(adhanUrl, `${prayerKey} আযান`, 'adhan');
        }
      } else {
        // If we've already played it, check if we're still in the window
        // and if the current track is NOT an adhan.
        // If it's not an adhan, it might mean we missed the transition 
        // or something else replaced it. But for now, if it's already marked as played,
        // we should just let it be or continue with normal rotation if the adhan is likely finished.
        
        // Let's check if the current track is adhan
        if (session?.current_track_type === 'adhan') {
          console.log(`আযান ইতিমধ্যে বাজছে, নতুন করে শুরু করা হবে না`);
          return getRadioSession().then(s => s.track);
        }
      }
    }
  }
  
  // STEP 4: Check for Scheduled News/Programs (HIGH PRIORITY - ALSO INTERRUPTS)
  // Look for any scheduled track that is due in the last 15 minutes but hasn't played yet
  const { data: scheduled } = await supabase
    .from('tracks')
    .select('*')
    .in('type', ['news', 'program'])
    .not('scheduled_time', 'is', null)
    .order('last_played_at', { ascending: true, nullsFirst: true })
    .limit(10); // Check a few of them

  if (scheduled && scheduled.length > 0) {
    for (const track of scheduled) {
      if (!track.scheduled_time) continue;
      
      const [sh, sm] = track.scheduled_time.split(':').map(Number);
      const targetTotal = sh * 60 + sm;
      const currentH = bdTime.getHours();
      const currentM = bdTime.getMinutes();
      const currentTotal = currentH * 60 + currentM;
      
      // If we are within the window (e.g., 0 to 30 minutes after scheduled time) 
      // AND it hasn't been played in the last hour
      const diff = currentTotal - targetTotal;
      const lastPlayed = track.last_played_at ? new Date(track.last_played_at) : null;
      const hourMs = 3600000;
      
      const shouldPlayNow = diff >= 0 && diff < 30 && (!lastPlayed || (now.getTime() - lastPlayed.getTime() > hourMs));
      
      if (shouldPlayNow) {
        console.log(`সিডিউল করা ট্র্যাক পাওয়া গেছে: ${track.title} (${track.scheduled_time})`);
        
        // INTERRUPT current playback if needed (for news and programs)
        if (session?.current_track_id && !session?.interrupted_track_id) {
          await saveInterruptState(session.current_track_id, 0, track.type);
        }

        // Check if track has its own intro_url
        if (track.intro_url) {
          // Play track's own intro first
          const introTrack = createPrayerTrack(track.intro_url, `${track.title} ইন্ট্রো`, 'intro');
          await supabase.from('radio_session').update({
            pending_content_type: track.type,
            pending_content_id: track.id
          }).eq('id', 1);
          return introTrack;
        }

        // Otherwise, try to find a generic intro based on type
        const introType = track.type === 'news' ? 'news_intro' : 'program_intro';
        const { data: intros } = await supabase
          .from('tracks')
          .select('*')
          .eq('type', 'jingle')
          .eq('intro_type', introType)
          .order('last_played_at', { ascending: true, nullsFirst: true })
          .limit(1);

        if (intros && intros.length > 0) {
          const intro = intros[0];
          await supabase.from('radio_session').update({
            pending_content_type: track.type,
            pending_content_id: track.id
          }).eq('id', 1);
          await supabase.from('tracks').update({ last_played_at: now.toISOString() }).eq('id', intro.id);
          return intro;
        }

        // No intro, play directly
        await supabase.from('tracks').update({ last_played_at: now.toISOString() }).eq('id', track.id);
        return track;
      }
    }
  }

  // STEP 5: Play Station ID between songs (30% chance)
  const chance = Math.random();
  if (chance < 0.3) {
    const { data: stationIds } = await supabase
      .from('tracks')
      .select('*')
      .eq('type', 'jingle')
      .eq('intro_type', 'station_id')
      .order('last_played_at', { ascending: true, nullsFirst: true })
      .limit(1);
      
    if (stationIds && stationIds.length > 0) {
      const stationId = stationIds[0];
      await supabase.from('tracks').update({ last_played_at: now.toISOString() }).eq('id', stationId.id);
      return stationId;
    }
  }

  // STEP 6: Normal Songs
  const { data: songs } = await supabase
    .from('tracks')
    .select('*')
    .eq('type', 'song')
    .order('last_played_at', { ascending: true, nullsFirst: true })
    .limit(1);

  if (songs && songs.length > 0) {
    await supabase.from('tracks').update({ last_played_at: now.toISOString() }).eq('id', songs[0].id);
    return songs[0];
  }

  return null;
};

// Playlists
export const fetchPlaylists = async () => {
  const { data, error } = await supabase.from('playlists').select('*, tracks(*)').order('created_at', { ascending: false });
  // Since we use junction table, we need a better query or separate fetch
  if (error) throw error;
  return data as Playlist[];
};

export const fetchPlaylistWithTracks = async (playlistId: string) => {
  const { data, error } = await supabase
    .from('playlists')
    .select(`
      *,
      playlist_tracks (
        track_id,
        position,
        tracks (*)
      )
    `)
    .eq('id', playlistId)
    .single();

  if (error) throw error;
  
  const tracks = data.playlist_tracks
    .sort((a: any, b: any) => a.position - b.position)
    .map((pt: any) => pt.tracks);
    
  return { ...data, tracks } as Playlist;
};

export const createPlaylist = async (name: string, type: string) => {
  const { data, error } = await supabase.from('playlists').insert({ name, type }).select().single();
  if (error) throw error;
  return data as Playlist;
};

export const addTrackToPlaylist = async (playlist_id: string, track_id: string, position: number) => {
  const { error } = await supabase.from('playlist_tracks').insert({ playlist_id, track_id, position });
  if (error) throw error;
};

// Settings
export const fetchSettings = async () => {
  const { data, error } = await supabase.from('station_settings').select('*').eq('id', 1).single();
  if (error) throw error;
  return data as StationSettings;
};

export const updateSettings = async (settings: Partial<StationSettings>) => {
  const { data, error } = await supabase.from('station_settings').update(settings).eq('id', 1).select().single();
  if (error) throw error;
  return data as StationSettings;
};

// Profiles
export const fetchProfile = async (uid: string) => {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', uid).single();
  if (error) throw error;
  return data as Profile;
};

