import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Trash2, 
  Music, 
  Image as ImageIcon, 
  Bell, 
  Newspaper, 
  Settings, 
  Upload, 
  Loader2, 
  LogOut, 
  Shuffle, 
  ListOrdered, 
  Clock,
  Radio,
  Calendar,
  Edit,
  Users,
  Activity,
  Headphones,
  TrendingUp,
  MessageSquare,
  ExternalLink,
  Tv,
  DollarSign
} from 'lucide-react';
import { 
  fetchNews, createNews, deleteNews, 
  fetchNotices, createNotice, deleteNotice,
  fetchSlider, createSliderImage, deleteSliderImage,
  fetchTracks, createTrack, deleteTrack, updateTrack,
  fetchSettings, updateSettings,
  fetchDashboardStats,
  fetchPrayerTimes
} from '@/db/api';
import { News, Notice, SliderImage, Track, StationSettings, AudioType, DashboardStats } from '../types/types';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

import { Progress } from '@/components/ui/progress';
import * as mm from 'music-metadata-browser';
import { motion } from 'framer-motion';
import { ScheduleManager } from '@/components/ScheduleManager';
import { PrayerTimesManager } from '@/components/PrayerTimesManager';
import { PrayerTimesManagerEnhanced } from '@/components/PrayerTimesManagerEnhanced';
import { ProgramsManager } from '@/components/ProgramsManager';
import { NewsContentManager } from '@/components/NewsContentManager';
import { ProgramContentManager } from '@/components/ProgramContentManager';
import { AdvertisementManager } from '@/components/AdvertisementManager';
import { ExternalStreamsManager } from '@/components/ExternalStreamsManager';
import { CommentsManager } from '@/components/CommentsManager';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

const Dashboard: React.FC = () => {
  const { signOut, profile, loading } = useAuth();
  const [news, setNews] = useState<News[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [sliders, setSliders] = useState<SliderImage[]>([]);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [settings, setSettings] = useState<StationSettings | null>(null);
  const [stats, setStats] = useState<DashboardStats | null>(null);

  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  useEffect(() => {
    loadData();
    // Refresh stats every 30 seconds
    const statsInterval = setInterval(loadStats, 30000);
    return () => clearInterval(statsInterval);
  }, []);

  const loadStats = async () => {
    try {
      const statsData = await fetchDashboardStats();
      setStats(statsData);
    } catch (err) {
      console.error('Stats load error:', err);
    }
  };

  const loadData = async () => {
    try {
      const [newsData, noticesData, slidersData, tracksData, settingsData] = await Promise.all([
        fetchNews(),
        fetchNotices(),
        fetchSlider(),
        fetchTracks(), // Fetch all types
        fetchSettings()
      ]);
      setNews(newsData);
      setNotices(noticesData);
      setSliders(slidersData);
      setTracks(tracksData);
      setSettings(settingsData);
      
      // Load stats
      await loadStats();
    } catch (err) {
      console.error(err);
      toast.error('ডেটা লোড করতে ব্যর্থ হয়েছে');
    }
  };

  const handleFileUpload = async (file: File, bucket: string) => {
    try {
      setIsUploading(true);
      setUploadProgress(0);

      const fileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '')}`;

      // We use a custom fetch/xhr if onUploadProgress isn't supported by the version
      // but let's try the modern way first.
      const { data, error } = await supabase.storage
        .from(bucket)
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false,
          // @ts-ignore - Some versions might have different types for onUploadProgress
          onUploadProgress: (progress) => {
            const percent = Math.round((progress.loaded / progress.total) * 100);
            setUploadProgress(percent);
          }
        });

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from(bucket)
        .getPublicUrl(data.path);

      return publicUrl;
    } catch (err) {
      console.error(err);
      toast.error('ফাইল আপলোড ব্যর্থ হয়েছে');
      return null;
    } finally {
      setIsUploading(false);
      // Wait a bit before hiding progress for better UX
      setTimeout(() => setUploadProgress(0), 1000);
    }
  };

  // Sub-components for Each Section
  const NewsManager = () => {
    const [content, setContent] = useState('');
    const handleAdd = async () => {
      if (!content) return;
      await createNews(content);
      setContent('');
      loadData();
      toast.success('নিউজ যোগ করা হয়েছে');
    };
    return (
      <Card>
        <CardHeader><CardTitle>ব্রেকিং নিউজ ম্যানেজমেন্ট</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input value={content} onChange={e => setContent(e.target.value)} placeholder="নতুন নিউজ লিখুন..." />
            <Button onClick={handleAdd}><Plus className="w-4 h-4 mr-1" /> যোগ করুন</Button>
          </div>
          <div className="space-y-2">
            {news.map(item => (
              <div key={item.id} className="flex justify-between items-center p-2 border rounded">
                <span>{item.content}</span>
                <Button variant="ghost" size="icon" onClick={() => deleteNews(item.id).then(loadData)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  };

  const NoticeManager = () => {
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const handleAdd = async () => {
      if (!title || !content) return;
      await createNotice(title, content);
      setTitle(''); setContent('');
      loadData();
      toast.success('নোটিশ যোগ করা হয়েছে');
    };
    return (
      <Card>
        <CardHeader><CardTitle>নোটিশ বোর্ড ম্যানেজমেন্ট</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="নোটিশ টাইটেল" />
          <Textarea value={content} onChange={e => setContent(e.target.value)} placeholder="নোটিশ বিষয়বস্তু" />
          <Button onClick={handleAdd} className="w-full"><Plus className="w-4 h-4 mr-1" /> যোগ করুন</Button>
          <div className="space-y-2">
            {notices.map(item => (
              <div key={item.id} className="p-3 border rounded space-y-1 relative group">
                <h4 className="font-bold">{item.title}</h4>
                <p className="text-sm text-muted-foreground">{item.content}</p>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => deleteNotice(item.id).then(loadData)}
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  };

  const SliderManager = () => {
    const handleAdd = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const url = await handleFileUpload(file, 'tangail_radio_images');
      if (url) {
        await createSliderImage(url);
        loadData();
        toast.success('স্লাইডার ছবি যোগ করা হয়েছে');
      }
    };
    return (
      <Card>
        <CardHeader><CardTitle>পিকচার স্লাইডার ম্যানেজমেন্ট</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-muted-foreground/20 rounded-xl p-8 bg-muted/10">
            <ImageIcon className="w-10 h-10 text-muted-foreground mb-4" />
            <Button asChild disabled={isUploading}>
              <label>
                {isUploading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
                ছবি আপলোড করুন (Gallery)
                <input type="file" className="hidden" accept="image/*" onChange={handleAdd} />
              </label>
            </Button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {sliders.map(item => (
              <div key={item.id} className="relative group rounded-lg overflow-hidden h-32">
                <img src={item.image_url} className="w-full h-full object-cover" />
                <Button 
                  variant="destructive" 
                  size="icon" 
                  className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => deleteSliderImage(item.id).then(loadData)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  };

  const TrackManager = () => {
    const [title, setTitle] = useState('');
    const [artist, setArtist] = useState('');
    const [audioUrl, setAudioUrl] = useState('');
    const [duration, setDuration] = useState<number | undefined>(undefined);
    const [type, setType] = useState<AudioType>('song');
    const [introType, setIntroType] = useState<'station_id' | 'adhan_intro' | 'news_intro' | 'program_intro' | ''>('');
    const [scheduledTime, setScheduledTime] = useState('');
    const [isExtracting, setIsExtracting] = useState(false);
    const [uploadType, setUploadType] = useState<'file' | 'link'>('file');
    const [editingTrack, setEditingTrack] = useState<Track | null>(null);
    const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
    const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

    const handleOpenEditDialog = (track: Track) => {
      setEditingTrack(track);
      setTitle(track.title);
      setArtist(track.artist || '');
      setType(track.type || 'song');
      setIntroType(track.intro_type || '');
      setScheduledTime(track.scheduled_time || '');
      setIsEditDialogOpen(true);
    };

    const handleSaveEdit = async () => {
      if (!editingTrack) return;
      try {
        await updateTrack(editingTrack.id, {
          title,
          artist,
          type,
          intro_type: introType || undefined,
          scheduled_time: scheduledTime || undefined
        });
        toast.success('গান আপডেট করা হয়েছে');
        setIsEditDialogOpen(false);
        setEditingTrack(null);
        loadData();
      } catch (err) {
        console.error(err);
        toast.error('আপডেট করতে ব্যর্থ হয়েছে');
      }
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files.length > 0) {
        const files = Array.from(e.target.files);
        setSelectedFiles(files);
        
        if (files.length === 1) {
          const file = files[0];
          setIsExtracting(true);
          try {
            const metadata = await mm.parseBlob(file);
            if (metadata.common.title) setTitle(metadata.common.title);
            if (metadata.common.artist) setArtist(metadata.common.artist);
            if (metadata.format.duration) setDuration(Math.round(metadata.format.duration));
            toast.success('মেটাডেটা সংগৃহীত হয়েছে');
          } catch (err) {
            console.warn('Metadata extraction failed', err);
            if (!title) setTitle(file.name.replace(/\.[^/.]+$/, ""));
          } finally {
            setIsExtracting(false);
          }
        } else {
          setTitle(`${files.length} টি ফাইল নির্বাচিত`);
          setArtist('');
          toast.success(`${files.length} টি ফাইল নির্বাচিত হয়েছে`);
        }
      }
    };

    const handleAdd = async (e: React.FormEvent) => {
      e.preventDefault();

      if (uploadType === 'link' && !title) {
        toast.error('গানের শিরোনাম দিন');
        return;
      }

      if (uploadType === 'file') {
        if (selectedFiles.length === 0) {
          toast.error('একটি অডিও ফাইল নির্বাচন করুন');
          return;
        }

        setIsUploading(true);
        let successCount = 0;

        for (const file of selectedFiles) {
          try {
            setUploadProgress(0);
            
            let trackTitle = title;
            let trackArtist = artist || '';
            let trackDuration = duration;

            if (selectedFiles.length > 1) {
              trackTitle = file.name.replace(/\.[^/.]+$/, "");
              try {
                const metadata = await mm.parseBlob(file);
                if (metadata.common.title) trackTitle = metadata.common.title;
                if (metadata.common.artist) trackArtist = metadata.common.artist;
                if (metadata.format.duration) trackDuration = Math.round(metadata.format.duration);
              } catch (err) { /* ignore */ }
            }

            const fileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '')}`;
            
            const { data, error } = await supabase.storage
              .from('tangail_radio_audio')
              .upload(fileName, file, {
                cacheControl: '3600',
                upsert: false,
                // @ts-ignore
                onUploadProgress: (progress) => {
                  const percent = Math.round((progress.loaded / progress.total) * 100);
                  setUploadProgress(percent);
                }
              });

            if (error) throw error;

            const { data: { publicUrl } } = supabase.storage
              .from('tangail_radio_audio')
              .getPublicUrl(data.path);

            await createTrack({ 
              title: trackTitle, 
              artist: trackArtist || artist,
              audio_url: publicUrl, 
              duration: trackDuration,
              type,
              intro_type: introType || undefined,
              scheduled_time: scheduledTime || undefined
            });
            successCount++;
          } catch (err) {
            console.error(`Upload failed for ${file.name}`, err);
            toast.error(`${file.name} আপলোড ব্যর্থ হয়েছে`);
          }
        }

        setIsUploading(false);
        setUploadProgress(0);
        
        if (successCount > 0) {
          toast.success(`${successCount} টি গান সফলভাবে যুক্ত করা হয়েছে`);
          setTitle('');
          setArtist('');
          setAudioUrl('');
          setScheduledTime('');
          setDuration(undefined);
          setSelectedFiles([]);
          const fileInput = document.getElementById('audio-upload') as HTMLInputElement;
          if (fileInput) fileInput.value = '';
          loadData();
        }
      } else {
        if (!audioUrl) {
          toast.error('অডিও লিংক দিন');
          return;
        }

        setIsUploading(true);
        try {
          const { data, error } = await supabase.functions.invoke('upload-from-url', {
            body: { url: audioUrl }
          });

          if (error) {
            const errorMsg = await error?.context?.text();
            throw new Error(errorMsg || error?.message);
          }
          if (data?.error) throw new Error(data.error);

          if (data?.publicUrl) {
            await createTrack({ 
              title, 
              artist, 
              audio_url: data.publicUrl, 
              duration,
              type,
              intro_type: introType || undefined,
              scheduled_time: scheduledTime || undefined
            });
            toast.success('লিংক থেকে গান যুক্ত করা হয়েছে');
            setTitle('');
            setArtist('');
            setAudioUrl('');
            setScheduledTime('');
            setDuration(undefined);
            loadData();
          }
        } catch (err: any) {
          console.error('URL upload failed', err);
          toast.error(`লিংক থেকে আপলোড ব্যর্থ হয়েছে: ${err.message}`);
        } finally {
          setIsUploading(false);
        }
      }
    };

    return (
      <Card>
        <CardHeader>
          <CardTitle>গান আপলোড সিস্টেম</CardTitle>
          <CardDescription>অডিও ফাইল বা লিংক থেকে গান যুক্ত করুন।</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Tabs value={uploadType} onValueChange={(val) => setUploadType(val as 'file' | 'link')} className="w-full">
            <TabsList className="grid grid-cols-2 w-full mb-4">
              <TabsTrigger value="file">গ্যালারি থেকে আপলোড</TabsTrigger>
              <TabsTrigger value="link">লিংক থেকে আপলোড</TabsTrigger>
            </TabsList>

            <form onSubmit={handleAdd} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">কন্টেন্ট শিরোনাম</label>
                  <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="শিরোনাম" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">শিল্পী/বিবরণ</label>
                  <Input value={artist} onChange={e => setArtist(e.target.value)} placeholder="শিল্পীর নাম বা বিবরণ" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">কন্টেন্ট টাইপ</label>
                  <select 
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    value={type}
                    onChange={(e) => setType(e.target.value as AudioType)}
                  >
                    <option value="song">গান (Song)</option>
                    <option value="jingle">ইন্ট্রো/জিঙ্গেল (Jingle)</option>
                    <option value="news">সংবাদ (News)</option>
                    <option value="adhan">আযান (Adhan)</option>
                    <option value="program">অনুষ্ঠান (Program)</option>
                  </select>
                </div>
                {type === 'jingle' && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">ইন্ট্রো টাইপ (জিঙ্গেলের জন্য)</label>
                    <select 
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      value={introType}
                      onChange={(e) => setIntroType(e.target.value as any)}
                    >
                      <option value="">সাধারণ জিঙ্গেল</option>
                      <option value="station_id">স্টেশন আইডি (গানের মাঝে)</option>
                      <option value="adhan_intro">আযান ইন্ট্রো (আযানের আগে)</option>
                      <option value="news_intro">সংবাদ ইন্ট্রো (সংবাদের আগে)</option>
                      <option value="program_intro">অনুষ্ঠান ইন্ট্রো (অনুষ্ঠানের আগে)</option>
                    </select>
                    <p className="text-xs text-muted-foreground">
                      ইন্ট্রো টাইপ নির্বাচন করলে সংশ্লিষ্ট কন্টেন্টের আগে স্বয়ংক্রিয়ভাবে প্লে হবে
                    </p>
                  </div>
                )}
                <div className="space-y-2">
                  <label className="text-sm font-medium">নির্ধারিত সময় (ঐচ্ছিক - আযান/সংবাদের জন্য)</label>
                  <Input 
                    type="time" 
                    value={scheduledTime} 
                    onChange={e => setScheduledTime(e.target.value)} 
                  />
                </div>
              </div>

              <TabsContent value="file" className="m-0 space-y-4">
                <div className="flex flex-col items-center justify-center border-2 border-dashed border-muted-foreground/20 rounded-xl p-8 bg-muted/10 relative">
                  <Music className={`w-12 h-12 text-muted-foreground mb-4 ${isExtracting ? 'animate-pulse' : ''}`} />
                  <p className="text-sm text-muted-foreground mb-4 text-center">অডিও ফাইলটি এখানে টেনে আনুন অথবা ক্লিক করুন (একাধিক গান আপলোড করা যাবে, সাইজ লিমিট নেই)</p>
                  <Input 
                    id="audio-upload"
                    type="file" 
                    className="hidden" 
                    accept="audio/*" 
                    onChange={handleFileChange}
                    disabled={isUploading}
                    multiple
                  />
                  <Button type="button" variant="outline" asChild disabled={isUploading}>
                    <label htmlFor="audio-upload" className="cursor-pointer">
                      {isExtracting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
                      ফাইল নির্বাচন করুন
                    </label>
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="link" className="m-0 space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">অডিও লিংক (Direct MP3 Link)</label>
                  <Input 
                    value={audioUrl} 
                    onChange={e => setAudioUrl(e.target.value)} 
                    placeholder="https://example.com/song.mp3" 
                    type="url"
                  />
                  <p className="text-[10px] text-muted-foreground">আমরা সরাসরি লিংক থেকে ফাইলটি আমাদের স্টোরেজে ডাউনলোড করে নেব।</p>
                </div>
              </TabsContent>

              {isUploading && uploadType === 'file' && (
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-medium">
                    <span>আপলোড হচ্ছে...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} className="h-2" />
                </div>
              )}

              {isUploading && uploadType === 'link' && (
                <div className="flex items-center justify-center gap-2 text-sm text-primary py-2 animate-pulse">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  লিংক থেকে প্রসেস করা হচ্ছে...
                </div>
              )}

              <Button type="submit" className="w-full" disabled={isUploading || isExtracting}>
                {isUploading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {uploadType === 'file' ? 'আপলোড করা হচ্ছে...' : 'প্রসেস করা হচ্ছে...'}
                  </>
                ) : (
                  'যুক্ত করুন'
                )}
              </Button>
            </form>
          </Tabs>

          <div className="space-y-2">
            <h3 className="font-bold text-sm border-b pb-2">গ্যালারি ({tracks.length})</h3>
            <div className="grid grid-cols-1 gap-2 max-h-[400px] overflow-y-auto pr-2">
              {tracks.map(item => (
                <div key={item.id} className="flex justify-between items-center p-3 border rounded-lg bg-card hover:bg-muted/50 transition-colors group">
                  <div className="flex items-center gap-3">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <Music className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm">{item.title}</h4>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground uppercase font-bold">
                          {item.type || 'song'}
                        </span>
                        {item.scheduled_time && (
                          <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded font-bold">
                            <Clock className="w-2.5 h-2.5 inline mr-1" /> {item.scheduled_time}
                          </span>
                        )}
                        <p className="text-xs text-muted-foreground">{item.artist || 'অজানা শিল্পী'}</p>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => handleOpenEditDialog(item)}
                    >
                      <Edit className="w-4 h-4 text-primary" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => {
                        if(confirm('আপনি কি এই গানটি মুছে ফেলতে চান?')) {
                          deleteTrack(item.id).then(loadData);
                        }
                      }}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))}
              {tracks.length === 0 && (
                <p className="text-center text-muted-foreground py-8 text-sm italic">কোনো গান পাওয়া যায়নি।</p>
              )}
            </div>
          </div>
        </CardContent>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>গান সম্পাদনা করুন</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label>শিরোনাম</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>
              <div>
                <Label>শিল্পী</Label>
                <Input value={artist} onChange={(e) => setArtist(e.target.value)} />
              </div>
              <div>
                <Label>কন্টেন্ট টাইপ</Label>
                <select 
                  value={type} 
                  onChange={(e) => setType(e.target.value as AudioType)}
                  className="w-full p-2 border rounded-md bg-background"
                >
                  <option value="song">গান</option>
                  <option value="jingle">জিঙ্গেল/ইন্ট্রো</option>
                  <option value="news">সংবাদ</option>
                  <option value="adhan">আযান</option>
                  <option value="program">অনুষ্ঠান</option>
                </select>
              </div>
              {type === 'jingle' && (
                <div>
                  <Label>ইন্ট্রো টাইপ</Label>
                  <select 
                    value={introType} 
                    onChange={(e) => setIntroType(e.target.value as any)}
                    className="w-full p-2 border rounded-md bg-background"
                  >
                    <option value="">সাধারণ জিঙ্গেল</option>
                    <option value="station_id">স্টেশন আইডি</option>
                    <option value="adhan_intro">আযান ইন্ট্রো</option>
                    <option value="news_intro">সংবাদ ইন্ট্রো</option>
                    <option value="program_intro">অনুষ্ঠান ইন্ট্রো</option>
                  </select>
                </div>
              )}
              {(type === 'news' || type === 'adhan' || type === 'program') && (
                <div>
                  <Label>নির্ধারিত সময় (ঐচ্ছিক)</Label>
                  <Input 
                    type="time" 
                    value={scheduledTime} 
                    onChange={(e) => setScheduledTime(e.target.value)} 
                  />
                </div>
              )}
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>বাতিল</Button>
                <Button onClick={handleSaveEdit}>সংরক্ষণ করুন</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </Card>
    );
  };

  const SettingsManager = () => {
    const [localSettings, setLocalSettings] = useState<StationSettings | null>(settings);
    useEffect(() => { setLocalSettings(settings); }, [settings]);
    const handleSave = async () => {
      if (!localSettings) return;
      await updateSettings(localSettings);
      loadData();
      toast.success('সেটিংস আপডেট করা হয়েছে');
    };
    if (!localSettings) return null;
    return (
      <Card>
        <CardHeader><CardTitle>স্টেশন সেটিংস</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">স্টেশনের নাম</label>
              <Input value={localSettings.name} onChange={e => setLocalSettings({...localSettings, name: e.target.value})} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">চেয়ারম্যান</label>
              <Input value={localSettings.chairman} onChange={e => setLocalSettings({...localSettings, chairman: e.target.value})} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">মোবাইল</label>
              <Input value={localSettings.mobile} onChange={e => setLocalSettings({...localSettings, mobile: e.target.value})} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">ইমেইল</label>
              <Input value={localSettings.email} onChange={e => setLocalSettings({...localSettings, email: e.target.value})} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-medium">ঠিকানা</label>
              <Input value={localSettings.address} onChange={e => setLocalSettings({...localSettings, address: e.target.value})} />
            </div>
          </div>
        </CardContent>
        <CardFooter><Button onClick={handleSave} className="w-full">সংরক্ষণ করুন</Button></CardFooter>
      </Card>
    );
  };

  const AutoDJManager = () => {
    const handleModeChange = async (mode: 'shuffle' | 'sequential') => {
      if (!settings) return;
      await updateSettings({ playback_mode: mode });
      loadData();
      toast.success(`${mode === 'shuffle' ? 'শাফেল' : 'সিকুয়েনশিয়াল'} মোড সেট করা হয়েছে`);
    };

    return (
      <Card>
        <CardHeader>
          <CardTitle>Auto DJ ফিচার & প্লেলিস্ট বিল্ডার</CardTitle>
          <CardDescription>আপনার স্টেশন সচল রাখতে অটো ডিজে সেটিংস সেট করুন</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card 
              className={`hover:border-primary transition-colors cursor-pointer p-4 flex flex-col items-center gap-2 ${settings?.playback_mode === 'shuffle' ? 'border-primary bg-primary/5' : 'bg-muted/10 opacity-50'}`}
              onClick={() => handleModeChange('shuffle')}
            >
              <Shuffle className="w-8 h-8 text-primary" />
              <span className="font-bold text-sm">শাফেল মোড</span>
              <span className="text-xs text-center text-muted-foreground">সব গান এলোমেলোভাবে চলবে</span>
            </Card>
            <Card 
              className={`hover:border-primary transition-colors cursor-pointer p-4 flex flex-col items-center gap-2 ${settings?.playback_mode === 'sequential' ? 'border-primary bg-primary/5' : 'bg-muted/10 opacity-50'}`}
              onClick={() => handleModeChange('sequential')}
            >
              <ListOrdered className="w-8 h-8 text-primary" />
              <span className="font-bold text-sm">সিকুয়েনশিয়াল মোড</span>
              <span className="text-xs text-center text-muted-foreground">সিরিয়াল অনুযায়ী গান চলবে</span>
            </Card>
          </div>

          <div className="border rounded-xl p-4">
            <h3 className="font-bold mb-4">প্লেলিস্ট বিল্ডার (বর্তমানে একটি প্লেলিস্ট সাপোর্ট করে)</h3>
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
              {tracks.map((track, i) => (
                <div key={track.id} className="flex items-center gap-3 p-2 border rounded bg-background">
                  <span className="text-muted-foreground text-xs w-4">{i + 1}</span>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{track.title}</p>
                    <p className="text-[10px] text-muted-foreground">{track.artist}</p>
                  </div>
                  <Music className="w-4 h-4 text-primary opacity-50" />
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const ScheduleManager = () => {
    const [scheduledTracks, setScheduledTracks] = useState<Track[]>([]);
    const [prayerSchedule, setPrayerSchedule] = useState<any>(null);
    const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
    const [editingTrack, setEditingTrack] = useState<Track | null>(null);
    
    // ফর্ম স্টেট
    const [scheduleTitle, setScheduleTitle] = useState('');
    const [scheduleType, setScheduleType] = useState<'news' | 'program'>('news');
    const [scheduleTime, setScheduleTime] = useState('');
    const [scheduleHost, setScheduleHost] = useState('');

    useEffect(() => {
      loadSchedule();
    }, []);

    const loadSchedule = async () => {
      try {
        // Load scheduled tracks
        const allTracks = await fetchTracks();
        const scheduled = allTracks.filter(t => t.scheduled_time);
        setScheduledTracks(scheduled.sort((a, b) => {
          const timeA = a.scheduled_time || '';
          const timeB = b.scheduled_time || '';
          return timeA.localeCompare(timeB);
        }));

        // Load prayer times
        const prayers = await fetchPrayerTimes();
        setPrayerSchedule(prayers);
      } catch (error) {
        console.error('Error loading schedule:', error);
      }
    };

    // ২৪ ঘণ্টা থেকে ১২ ঘণ্টা ফরম্যাটে রূপান্তর
    const convertTo12Hour = (time24: string) => {
      if (!time24) return '';
      const [hours, minutes] = time24.split(':').map(Number);
      const hour12 = hours % 12 || 12;
      const period = hours >= 5 && hours < 12 ? 'সকাল' : 
                     hours >= 12 && hours < 15 ? 'দুপুর' :
                     hours >= 15 && hours < 18 ? 'বিকাল' :
                     hours >= 18 && hours < 20 ? 'সন্ধ্যা' : 'রাত';
      return `${hour12}:${minutes.toString().padStart(2, '0')} ${period}`;
    };

    const getTypeLabel = (type?: string) => {
      switch (type) {
        case 'news': return 'সংবাদ';
        case 'program': return 'অনুষ্ঠান';
        case 'adhan': return 'আযান';
        default: return 'অন্যান্য';
      }
    };

    const getTypeBadgeColor = (type?: string) => {
      switch (type) {
        case 'news': return 'bg-blue-500/10 text-blue-700 dark:text-blue-300';
        case 'program': return 'bg-purple-500/10 text-purple-700 dark:text-purple-300';
        case 'adhan': return 'bg-green-500/10 text-green-700 dark:text-green-300';
        default: return 'bg-gray-500/10 text-gray-700 dark:text-gray-300';
      }
    };

    const handleAddSchedule = async () => {
      if (!scheduleTitle || !scheduleTime) {
        toast.error('শিরোনাম এবং সময় পূরণ করুন');
        return;
      }

      try {
        await createTrack({
          title: scheduleTitle,
          audio_url: '', // Placeholder - will be updated when audio is uploaded
          type: scheduleType,
          scheduled_time: scheduleTime,
          artist: scheduleHost || 'Tangail Radio'
        });
        
        toast.success('শিডিউল যুক্ত হয়েছে');
        setIsAddDialogOpen(false);
        setScheduleTitle('');
        setScheduleTime('');
        setScheduleHost('');
        loadSchedule();
      } catch (error) {
        console.error('Error adding schedule:', error);
        toast.error('শিডিউল যুক্ত করতে ব্যর্থ হয়েছে');
      }
    };

    const handleDeleteSchedule = async (id: string) => {
      if (!confirm('এই শিডিউলটি মুছে ফেলতে চান?')) return;
      
      try {
        await deleteTrack(id);
        toast.success('শিডিউল মুছে ফেলা হয়েছে');
        loadSchedule();
      } catch (error) {
        console.error('Error deleting schedule:', error);
        toast.error('মুছে ফেলতে ব্যর্থ হয়েছে');
      }
    };

    const handleEditSchedule = (track: Track) => {
      setEditingTrack(track);
      setScheduleTitle(track.title);
      setScheduleType(track.type as 'news' | 'program');
      setScheduleTime(track.scheduled_time || '');
      setScheduleHost(track.artist || '');
      setIsAddDialogOpen(true);
    };

    const handleUpdateSchedule = async () => {
      if (!editingTrack || !scheduleTitle || !scheduleTime) {
        toast.error('সকল তথ্য পূরণ করুন');
        return;
      }

      try {
        await updateTrack(editingTrack.id, {
          title: scheduleTitle,
          type: scheduleType,
          scheduled_time: scheduleTime,
          artist: scheduleHost || 'Tangail Radio'
        });
        
        toast.success('শিডিউল আপডেট হয়েছে');
        setIsAddDialogOpen(false);
        setEditingTrack(null);
        setScheduleTitle('');
        setScheduleTime('');
        setScheduleHost('');
        loadSchedule();
      } catch (error) {
        console.error('Error updating schedule:', error);
        toast.error('আপডেট করতে ব্যর্থ হয়েছে');
      }
    };

    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>দৈনিক শিডিউল</CardTitle>
              <CardDescription>আপনার রেডিও স্টেশনের সম্পূর্ণ দৈনিক কার্যক্রম</CardDescription>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={(open) => {
              setIsAddDialogOpen(open);
              if (!open) {
                setEditingTrack(null);
                setScheduleTitle('');
                setScheduleTime('');
                setScheduleHost('');
              }
            }}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  নতুন শিডিউল
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingTrack ? 'শিডিউল সম্পাদনা' : 'নতুন শিডিউল যুক্ত করুন'}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label>শিরোনাম *</Label>
                    <Input
                      value={scheduleTitle}
                      onChange={(e) => setScheduleTitle(e.target.value)}
                      placeholder="যেমন: সন্ধ্যা ৬টার সংবাদ"
                    />
                  </div>
                  <div>
                    <Label>ধরন *</Label>
                    <select
                      value={scheduleType}
                      onChange={(e) => setScheduleType(e.target.value as 'news' | 'program')}
                      className="w-full p-2 border rounded-md bg-background"
                    >
                      <option value="news">সংবাদ</option>
                      <option value="program">অনুষ্ঠান</option>
                    </select>
                  </div>
                  <div>
                    <Label>সময় *</Label>
                    <Input
                      type="time"
                      value={scheduleTime}
                      onChange={(e) => setScheduleTime(e.target.value)}
                    />
                  </div>
                  {scheduleType === 'program' && (
                    <div>
                      <Label>উপস্থাপক (ঐচ্ছিক)</Label>
                      <Input
                        value={scheduleHost}
                        onChange={(e) => setScheduleHost(e.target.value)}
                        placeholder="উপস্থাপকের নাম"
                      />
                    </div>
                  )}
                  <div className="bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3">
                    <p className="text-xs text-yellow-800 dark:text-yellow-200">
                      <strong>দ্রষ্টব্য:</strong> শিডিউল তৈরির পর "সংবাদ অডিও" বা "অনুষ্ঠান অডিও" ট্যাবে গিয়ে অডিও ফাইল আপলোড করুন।
                    </p>
                  </div>
                  <div className="flex gap-2 justify-end">
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>বাতিল</Button>
                    <Button onClick={editingTrack ? handleUpdateSchedule : handleAddSchedule}>
                      {editingTrack ? 'আপডেট করুন' : 'যুক্ত করুন'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* নামাজের সময়সূচী */}
          {prayerSchedule && prayerSchedule.active && (
            <div className="border rounded-xl p-4 bg-green-50 dark:bg-green-950/20">
              <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
                <Clock className="w-5 h-5 text-green-600" />
                নামাজের সময়সূচী
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {[
                  { name: 'ফজর', time: prayerSchedule.fajr_time },
                  { name: 'যোহর', time: prayerSchedule.dhuhr_time },
                  { name: 'আসর', time: prayerSchedule.asr_time },
                  { name: 'মাগরিব', time: prayerSchedule.maghrib_time },
                  { name: 'এশা', time: prayerSchedule.isha_time },
                  { name: 'জুম্মা', time: prayerSchedule.jummah_time }
                ].map((prayer) => (
                  <div key={prayer.name} className="bg-white dark:bg-gray-800 rounded-lg p-3 border">
                    <div className="text-sm font-bold text-green-700 dark:text-green-300">{prayer.name}</div>
                    <div className="text-lg font-black text-foreground">{convertTo12Hour(prayer.time)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* শিডিউলকৃত কন্টেন্ট */}
          <div>
            <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              শিডিউলকৃত সংবাদ ও অনুষ্ঠান ({scheduledTracks.length}টি)
            </h3>
            
            {scheduledTracks.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground border rounded-lg">
                কোনো শিডিউল নেই। উপরে "নতুন শিডিউল" বাটনে ক্লিক করুন।
              </div>
            ) : (
              <div className="space-y-2">
                {scheduledTracks.map((track) => (
                  <div
                    key={track.id}
                    className="border rounded-lg p-4 bg-card hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3 flex-1">
                        <div className="text-xl font-black text-primary">
                          {convertTo12Hour(track.scheduled_time || '')}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold">{track.title}</h4>
                            <span className={`text-xs px-2 py-1 rounded-full font-bold ${getTypeBadgeColor(track.type)}`}>
                              {getTypeLabel(track.type)}
                            </span>
                          </div>
                          {track.artist && track.artist !== 'Tangail Radio' && (
                            <p className="text-xs text-muted-foreground mt-1">{track.artist}</p>
                          )}
                          {track.intro_url && (
                            <p className="text-xs text-primary mt-1 flex items-center gap-1">
                              <Music className="w-3 h-3" />
                              ইন্ট্রো সহ
                            </p>
                          )}
                          {!track.audio_url && (
                            <p className="text-xs text-orange-600 mt-1 flex items-center gap-1">
                              <Upload className="w-3 h-3" />
                              অডিও আপলোড করুন
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditSchedule(track)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteSchedule(track.id)}
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <p className="text-sm text-blue-800 dark:text-blue-200">
              <strong>স্বয়ংক্রিয় প্লেব্যাক:</strong> নির্ধারিত সময়ে সংবাদ ও অনুষ্ঠান স্বয়ংক্রিয়ভাবে প্লে হবে। 
              নামাজের সময় সবকিছু বন্ধ হয়ে আযান প্লে হবে এবং শেষ হলে আগের কন্টেন্ট পুনরায় চালু হবে।
            </p>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (profile?.role !== 'admin') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4 text-center">
        <h1 className="text-2xl font-bold text-destructive mb-2">প্রবেশাধিকার নেই</h1>
        <p className="text-muted-foreground mb-4">এই পেজটি শুধুমাত্র অ্যাডমিনদের জন্য।</p>
        <Button onClick={() => signOut()}>লগ আউট করুন</Button>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-muted/20 flex flex-col"
    >
      <header className="bg-card border-b border-border p-4 sticky top-0 z-50 shadow-sm backdrop-blur-md bg-card/80">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-primary p-2 rounded-xl shadow-lg shadow-primary/20">
              <Radio className="text-white w-5 h-5" />
            </div>
            <h1 className="font-black text-xl tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60 hidden md:block">
              Tangail Radio Admin
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden md:block">
              <p className="text-[10px] text-muted-foreground uppercase font-bold">অ্যাডমিন প্যানেল</p>
              <p className="text-sm font-bold tracking-tight">স্বাগতম, {profile?.username as string}</p>
            </div>
            <Button variant="destructive" size="sm" onClick={() => signOut()} className="rounded-full px-6">
              <LogOut className="w-4 h-4 mr-2" /> লগ আউট
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-4 py-8 md:py-12">
        {/* Statistics Cards */}
        {stats && (
          <motion.div 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
          >
            <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-500/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground font-bold uppercase">মোট গান</p>
                    <p className="text-2xl font-black text-blue-600">{stats.total_songs}</p>
                  </div>
                  <Music className="w-8 h-8 text-blue-500 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-500/10 to-green-600/5 border-green-500/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground font-bold uppercase">মোট অনুষ্ঠান</p>
                    <p className="text-2xl font-black text-green-600">{stats.total_programs}</p>
                  </div>
                  <Radio className="w-8 h-8 text-green-500 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 border-purple-500/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground font-bold uppercase">অনলাইন শ্রোতা</p>
                    <p className="text-2xl font-black text-purple-600">{stats.online_listeners}</p>
                  </div>
                  <Activity className="w-8 h-8 text-purple-500 opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/5 border-orange-500/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground font-bold uppercase">মোট শ্রোতা</p>
                    <p className="text-2xl font-black text-orange-600">{stats.total_listeners}</p>
                  </div>
                  <Users className="w-8 h-8 text-orange-500 opacity-50" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <Tabs defaultValue="tracks" className="space-y-8">
          <div className="bg-card/50 backdrop-blur-sm p-1 rounded-2xl border border-border shadow-inner">
            <TabsList className="bg-transparent border-none w-full justify-start overflow-x-auto h-auto p-0 scrollbar-hide gap-1">
              <TabsTrigger value="tracks" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><Music className="w-4 h-4" /> গান আপলোড</TabsTrigger>
              <TabsTrigger value="news" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><Newspaper className="w-4 h-4" /> ব্রেকিং নিউজ</TabsTrigger>
              <TabsTrigger value="news_audio" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><Radio className="w-4 h-4" /> সংবাদ অডিও</TabsTrigger>
              <TabsTrigger value="programs" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><Tv className="w-4 h-4" /> অনুষ্ঠান অডিও</TabsTrigger>
              <TabsTrigger value="advertisements" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><DollarSign className="w-4 h-4" /> বিজ্ঞাপন</TabsTrigger>
              <TabsTrigger value="prayer" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><Clock className="w-4 h-4" /> নামাজ</TabsTrigger>
              <TabsTrigger value="streams" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><ExternalLink className="w-4 h-4" /> স্ট্রিম</TabsTrigger>
              <TabsTrigger value="comments" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><MessageSquare className="w-4 h-4" /> মন্তব্য</TabsTrigger>
              <TabsTrigger value="schedule" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><Calendar className="w-4 h-4" /> শিডিউল</TabsTrigger>
              <TabsTrigger value="autodj" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><Shuffle className="w-4 h-4" /> অটো ডিজে</TabsTrigger>
              <TabsTrigger value="settings" className="gap-2 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white py-2.5 px-6 transition-all font-bold"><Settings className="w-4 h-4" /> সেটিংস</TabsTrigger>
            </TabsList>
          </div>

          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            <TabsContent value="tracks" className="mt-0 focus-visible:outline-none"><TrackManager /></TabsContent>
            <TabsContent value="news" className="mt-0 focus-visible:outline-none"><NewsManager /></TabsContent>
            <TabsContent value="news_audio" className="mt-0 focus-visible:outline-none"><NewsContentManager /></TabsContent>
            <TabsContent value="notices" className="mt-0 focus-visible:outline-none"><NoticeManager /></TabsContent>
            <TabsContent value="slider" className="mt-0 focus-visible:outline-none"><SliderManager /></TabsContent>
            <TabsContent value="programs" className="mt-0 focus-visible:outline-none"><ProgramContentManager /></TabsContent>
            <TabsContent value="advertisements" className="mt-0 focus-visible:outline-none"><AdvertisementManager /></TabsContent>
            <TabsContent value="prayer" className="mt-0 focus-visible:outline-none"><PrayerTimesManagerEnhanced /></TabsContent>
            <TabsContent value="streams" className="mt-0 focus-visible:outline-none"><ExternalStreamsManager /></TabsContent>
            <TabsContent value="comments" className="mt-0 focus-visible:outline-none"><CommentsManager /></TabsContent>
            <TabsContent value="schedule" className="mt-0 focus-visible:outline-none"><ScheduleManager /></TabsContent>
            <TabsContent value="autodj" className="mt-0 focus-visible:outline-none"><AutoDJManager /></TabsContent>
            <TabsContent value="settings" className="mt-0 focus-visible:outline-none"><SettingsManager /></TabsContent>
          </motion.div>
        </Tabs>
      </main>
    </motion.div>
  );
};

export default Dashboard;
