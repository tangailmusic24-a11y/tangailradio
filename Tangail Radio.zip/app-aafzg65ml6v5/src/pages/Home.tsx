import React from 'react';
import { Layout } from '@/components/Layout';
import { Slider } from '@/components/Slider';
import { NoticeBoard } from '@/components/NoticeBoard';
import { CommentBox } from '@/components/CommentBox';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Radio, Users, Music, Activity, Headphones, Heart, Share2, Globe } from 'lucide-react';
import { motion } from 'framer-motion';

const Home: React.FC = () => {
  const stats = [
    { icon: Headphones, label: 'শ্রোতা', value: '৫০০০+', color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { icon: Music, label: 'গান', value: '১২০০+', color: 'text-purple-500', bg: 'bg-purple-500/10' },
    { icon: Globe, label: 'কভারেজ', value: 'বিশ্বজুড়ে', color: 'text-green-500', bg: 'bg-green-500/10' },
    { icon: Heart, label: 'পছন্দ', value: '৯৯%', color: 'text-red-500', bg: 'bg-red-500/10' },
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <Layout>
      <div className="space-y-12">
        <section className="relative">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="rounded-3xl overflow-hidden shadow-2xl border border-primary/10"
          >
            <Slider />
          </motion.div>
        </section>

        <motion.section 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6"
        >
          {stats.map((stat, i) => (
            <motion.div key={i} variants={item}>
              <Card className="border-none shadow-lg bg-card/50 backdrop-blur-sm hover:scale-105 transition-transform duration-300">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                  <div className={`p-4 rounded-2xl ${stat.bg} mb-4`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <h4 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-br from-foreground to-foreground/60">{stat.value}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.section>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <motion.section 
              initial={{ x: -20, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold border-l-4 border-primary pl-4">আমাদের অনুষ্ঠানমালা</h3>
                <Button variant="link" className="text-primary gap-2" onClick={() => {}}>সব দেখুন <Share2 className="w-4 h-4" /></Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="group hover:border-primary/50 transition-all cursor-pointer overflow-hidden border-none shadow-xl bg-gradient-to-br from-card to-muted/20">
                  <CardContent className="p-0">
                    <div className="aspect-video relative overflow-hidden">
                      <img src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_2d4575d0-8bae-4292-91ec-7228ca4a07d7.jpg" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="Show" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-4">
                        <span className="bg-primary text-white text-[10px] uppercase tracking-widest px-2 py-1 rounded w-fit mb-2">প্রতিদিন</span>
                        <h4 className="text-white font-bold text-lg">সকালের গান</h4>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="group hover:border-primary/50 transition-all cursor-pointer overflow-hidden border-none shadow-xl bg-gradient-to-br from-card to-muted/20">
                  <CardContent className="p-0">
                    <div className="aspect-video relative overflow-hidden">
                      <img src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_bec41438-0238-4a53-9e27-408e238db84e.jpg" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="Show" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-4">
                        <span className="bg-accent text-accent-foreground text-[10px] uppercase tracking-widest px-2 py-1 rounded w-fit mb-2">সপ্তাহিক</span>
                        <h4 className="text-white font-bold text-lg">টাঙ্গাইলের কথা</h4>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </motion.section>

            <motion.section 
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="bg-primary/5 rounded-3xl p-8 border border-primary/10"
            >
              <div className="flex flex-col md:flex-row gap-8 items-center">
                <div className="shrink-0">
                  <div className="w-20 h-20 bg-primary/20 rounded-2xl flex items-center justify-center">
                    <Radio className="w-10 h-10 text-primary" />
                  </div>
                </div>
                <div className="space-y-4 text-center md:text-left">
                  <h3 className="text-2xl font-bold tracking-tight">টাঙ্গাইল রেডিওর লক্ষ্য</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    টাঙ্গাইল রেডিও একটি আধুনিক অনলাইন ব্রডকাস্টিং প্ল্যাটফর্ম। আমরা মানসম্পন্ন কন্টেন্ট, গান এবং খবরের মাধ্যমে শ্রোতাদের বিনোদন ও তথ্য প্রদান করে আসছি। টাঙ্গাইলের ঐতিহ্য ও সংস্কৃতিকে ডিজিটাল মাধ্যমে তুলে ধরাই আমাদের প্রধান লক্ষ্য।
                  </p>
                </div>
              </div>
            </motion.section>
          </div>

          <motion.div 
            initial={{ x: 20, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="rounded-3xl overflow-hidden shadow-xl border border-primary/10">
              <NoticeBoard />
            </div>
            
            <Card className="bg-gradient-to-br from-primary to-primary/80 text-white border-none shadow-2xl rounded-3xl overflow-hidden relative group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform">
                <Radio className="w-24 h-24" />
              </div>
              <CardHeader>
                <CardTitle className="text-xl">আমাদের সাথে যুক্ত হোন</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6 relative">
                <p className="text-sm text-white/80">
                  টাঙ্গাইল রেডিওতে বিজ্ঞাপন দিতে বা কোনো প্রশ্ন থাকলে সরাসরি আমাদের কল করুন।
                </p>
                <div className="p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 flex items-center gap-4">
                  <div className="bg-white/20 p-3 rounded-full">
                    <Activity className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-[10px] text-white/60 uppercase font-bold tracking-widest">হটলাইন</p>
                    <p className="font-bold text-lg">01303216921</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* মন্তব্য বক্স */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <CommentBox />
        </motion.section>
      </div>
    </Layout>
  );
};

export default Home;
